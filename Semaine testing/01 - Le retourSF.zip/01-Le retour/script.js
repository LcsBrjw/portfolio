function jAimeLeJS() {
    return("J'aime le JS !");
    }
