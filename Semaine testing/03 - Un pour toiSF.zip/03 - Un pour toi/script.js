function youAndMe(prenom){
    if(prenom===""){
        console.log("Un pour toi, un pour moi.");
    }else{
        console.log("Un pour "+ prenom +", un pour moi.");
    }
}