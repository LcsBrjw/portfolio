function transform(x){
    if(x===0){
        console.log("zéro");
    }else if(x===1){
        console.log("un");
    }else if(x===2){
        console.log("deux");
    }
}